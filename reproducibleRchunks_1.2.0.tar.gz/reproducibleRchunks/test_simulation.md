---
title: "Use Case: Simulation"
output: html_document
date: "2025-07-01"
---



# Simulate Data


