## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----libs---------------------------------------------------------------------
library(reproducibleRchunks)
library(MASS)

