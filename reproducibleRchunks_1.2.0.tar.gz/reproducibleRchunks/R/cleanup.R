cleanup <- function()
{
  files <- get_all_metadata_files()

  # TODO check whether there are left-over metadata files

  stop("Not implemented yet")

}
