---
title: "Test Suite"
output: html_document
date: "2024-06-17"
---



## Test Suite

This test suite is for manual testing of whether code chunk options work properly. We are testing the following chunk options:

- `include` runs the code but doesn’t show the code or results in the document
- `echo` prevents code, but not the results from appearing in the document

### Test 1: Default options

This is supposed to show code, results and report:










