---
title: "Test JSON data storage using `testthat`"
output: html_document
date: "2024-05-31"
---



## Reproducible Computations

The following computations will be automatically tested for reproducibility with every build of this document.




